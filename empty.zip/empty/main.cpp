#include <bits/stdc++.h>
using namespace std;

//!A function to get the middle index from corner indexes
int getMid(int s, int e) { return s + (e -s)/2; }

//!Return sum of elements in range of given indexes
int getSum1(int *st, int le, int re, int l1, int r1, int sini)
{
    if (l1 <= le && r1 >= re)
        return st[sini];

    if (re < l1 || le > re)
        return 0;

    int mid = getMid(le, re);
    return getSum1(st, le, mid, l1, r1, 2*sini+1) +
        getSum1(st, mid+1, re, l1, r1, 2*sini+2);
}

//!calls the getSum1 method for getting sum
int getSum(int *st, int n, int l1, int r1)
{
    if (l1 < 0 || r1 > n-1 || l1 > r1)
    {
        cout<<"Invalid Input";
        return -1;
    }

    return getSum1(st, 0, n-1, l1, r1, 0);
}

//! A  function that constructs Segment Tree with sum
int segsum1(int arr[], int le, int re, int *st, int sini)
{
    if (le == re)
    {
        st[sini] = arr[le];
        return arr[le];
    }

    int mid = getMid(le, re);
    st[sini] = segsum1(arr, le, mid, st, sini*2+1) +
            segsum1(arr, mid+1, re, st, sini*2+2);
    return st[sini];
}

//! Function to construct segment tree and allocates memory for segment tree and calls segsum1 to fill the allocated memory
int *segsum(int arr[], int n)
{

    int x = (int)(ceil(log2(n)));
    int ms = 2*(int)pow(2, x) - 1;
    int *st = new int[ms];
    segsum1(arr, 0, n-1, st, 0);
    return st;
}
//!a function to calculate minimum of two given values
int minVal(int x, int y) { return (x < y)? x: y; }

//!A function to get the minimum value in a given range of array indexes
int getMin1(int *st, int le, int re, int l1, int r1, int index)
{
    if (l1 <= le && r1 >= re)
        return st[index];

    if (re < l1 || le > r1)
        return INT_MAX;

    int mid = getMid(le, re);
    return minVal(getMin1(st, le, mid, l1, r1, 2*index+1),
                getMin1(st, mid+1, re, l1, r1, 2*index+2));
}

//!Return minimum of elements in range and calls getMin1 for this
int getMin(int *st, int n, int l1, int r1)
{
    if (l1 < 0 || r1 > n-1 || l1 > r1)
    {
        cout<<"Invalid Input";
        return -1;
    }

    return getMin1(st, 0, n-1, l1, r1, 0);
}

//!A function that constructs Segment Tree with minimum values
int segmin1(int arr[], int le, int re,
                                int *st, int sini)
{
    if (le== re)
    {
        st[sini] = arr[le];
        return arr[le];
    }
    int mid = getMid(le, re);
    st[sini] = minVal(segmin1(arr, le, mid, st, sini*2+1),
                    segmin1(arr, mid+1, re, st, sini*2+2));
    return st[sini];
}

//!Function to construct segment tree and allocates memory for segment tree and calls segmin1 to fill the allocated memory
int *segmin(int arr[], int n)
{
    int x = (int)(ceil(log2(n)));
    int ms = 2*(int)pow(2, x) - 1;

    int *st = new int[ms];
    segmin1(arr, 0, n-1, st, 0);
    return st;
}

//!a function to calculate maximum of two given values
int maxVal(int x, int y) { return (x > y)? x: y; }

//!A function to get the maximum value in a given range of array indexes
int getMax1(int *st, int le, int re, int l1, int r1, int index)
{
    if (l1 <= le && r1 >= re)

        return st[index];
    if (re < l1 || le > re)
        return -INT_MAX;
    int mid = getMid(le, re);
    return maxVal(getMax1(st, le, mid, l1, r1, 2*index+1),
                getMax1(st, mid+1, re, l1, r1, 2*index+2));
}

//!Return minimum of elements in range and calls getMax1 for this
int getMax(int *st, int n, int l1, int r1)
{
    if (l1 < 0 || r1 > n-1 || l1 > r1)
    {
        cout<<"Invalid Input";
        return -1;
    }

    return getMax1(st, 0, n-1, l1, r1, 0);
}

//!A function that constructs Segment Tree with maximum values
int segmax1(int arr[], int le, int re,
                                int *st, int sini)
{
    if (le == re)
    {
        st[sini] = arr[le];
       // cout<<st[si]<<" ";
        return arr[le];
    }
    int mid = getMid(le, re);
    st[sini] = maxVal(segmax1(arr, le, mid, st, sini*2+1),
                    segmax1(arr, mid+1, re, st, sini*2+2));
    //cout<<st[si]<<" ";
    return st[sini];
}

//!Function to construct segment tree and allocates memory for segment tree and calls segmax1 to fill the allocated memory
int *segmax(int arr[], int n)
{
    int x = (int)(ceil(log2(n)));
    int ms = 2*(int)pow(2, x) - 1;
    int *st = new int[ms];
    segmax1(arr, 0, n-1, st, 0);
    return st;
}

//!a function to update values in given range and segment tree of sum values
int update(int *st, int le, int re, int l1,int r1, int diff, int sini)
{
    if (r1 < le || l1> re){
        return st[sini];
    }
     if (le == re&&le<=r1&&le>=l1)
    {
       // st[si] = arr[ss];
        st[sini] = st[sini] + diff;
        return st[sini];
    }
    if (re != le)
    {
        int mid = getMid(le, re);
        st[sini]=update(st, le, mid, l1,r1, diff, 2*sini + 1)+
        update(st, mid+1, re,l1,r1, diff, 2*sini + 2);
    }

    return st[sini];
}

//! The function to update values in given range and calls update for this
void updateValue(int arr[], int *st, int n, int l1,int r1, int diff)
{
    if (r1 < 0 || l1> n-1)
    {
        cout<<"Invalid Input";
        return;
    }
    st[0]=update(st, 0, n-1,l1,r1, diff, 0);
}

//!a function to update values in given range and segment tree of minimum values
int update1(int *st, int le, int re, int l1,int r1, int diff, int sini)
{
    if (r1 < le || l1> re){
        return st[sini];
    }
     if (le == re&&le<=r1&&le>=l1)
    {
       // st[si] = arr[ss];
        st[sini] = st[sini] + diff;
        return st[sini];
    }
    if (re != le)
    {
        int mid = getMid(le, re);
        st[sini]=minVal(update1(st, le, mid, l1,r1, diff, 2*sini + 1),
        update1(st, mid+1, re, l1,r1, diff, 2*sini + 2));
    }

    return st[sini];
}

//! The function to update values in given range and calls update1 for this
void updateValue1(int arr[], int *st, int n, int l1,int r1, int diff)
{
    if (r1 < 0 || l1> n-1)
    {
        cout<<"Invalid Input";
        return;
    }
    st[0]=update1(st, 0, n-1,l1,r1, diff, 0);
}

//!a function to update values in given range and segment tree of maximum values
int update2(int *st, int le, int re, int l1,int r1, int diff, int sini)
{
    if (r1 < le || l1> re){
        return st[sini];
    }
     if (le == re&&le<=r1&&le>=l1)
    {
        st[sini] = st[sini] + diff;
        return st[sini];
    }
    if (re != le)
    {
        int mid = getMid(le, re);
        st[sini]=maxVal(update2(st, le, mid, l1,r1, diff, 2*sini + 1),
        update2(st, mid+1, re, l1,r1, diff, 2*sini + 2));
    }
    return st[sini];
}

//! The function to update values in given range and calls update2 for this
void updateValue2(int arr[], int *st, int n, int l1,int r1, int diff)
{
    if (l1 < 0 || r1> n-1)
    {
        cout<<"Invalid Input";
        return;
    }
    st[0]=update2(st, 0, n-1,l1,r1, diff, 0);
}

//! The main method to initiate and call other functions
int main()
{   int n,l,r,i;
    cout<<"Enter the number of elements:";
    cin>>n;
    int *arr=new int[n];
    cout<<"Enter the values for elements of array:";
    for(i=0;i<n;i++){
        cin>>arr[i];
    }
    int *st = segsum(arr, n);
    cout<<"Enter the left index:";
    cin>>l;
    cout<<"Enter the right index:";
    cin>>r;
    cout<<"Sum of values in given range = "<<getSum(st, n, l, r)<<endl;
    updateValue(arr, st, n, l,r,4);
    cout<<"Updated sum of values in given range = "
            <<getSum(st, n, l,r)<<endl;
    st = segmin(arr, n);
    int l1 = l;
    int r1 = r;
    cout<<"Minimum of values in range ["<<l1<<", "<<r1<<"] "<<
    "is = "<<getMin(st, n, l1, r1)<<endl;
    updateValue1(arr, st, n, l,r,4);
    cout<<"Updated minimum of values in given range = "
            <<getMin(st, n, l1, r1)<<endl;
    st = segmax(arr, n);
     cout<<"Maximum of values in range ["<<l1<<", "<<r1<<"] "<<
    "is = "<<getMax(st, n, l1, r1)<<endl;
    updateValue2(arr, st, n, l,r,4);
    cout<<"Updated maximum of values in given range = "
            <<getMax(st, n, l1, r1)<<endl;
    return 0;
}










